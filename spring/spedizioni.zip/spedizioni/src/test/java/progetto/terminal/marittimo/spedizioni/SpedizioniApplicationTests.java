package progetto.terminal.marittimo.spedizioni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpedizioniApplicationTests {

	@Test
	void contextLoads() {
	}

}
